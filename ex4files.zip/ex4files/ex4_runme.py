"""
===================================================
     Introduction to Machine Learning (67577)
===================================================

Running script for Ex4.

Author:
Date: May, 2018

"""

import numpy as np

def Q3(): # AdaBoost
    # TODO - implement this function
    return

def Q4(): # decision trees
    # TODO - implement this function
    return

def Q5(): # spam data
    # TODO - implement this function
    return

if __name__ == '__main__':
    # TODO - run your code for questions 3-5
    pass
